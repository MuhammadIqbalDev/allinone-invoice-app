import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:invoice_app/blocs/bloc/buisness_bloc.dart';
import 'package:invoice_app/blocs/bloc/client_bloc.dart';
import 'package:invoice_app/blocs/bloc/invoice_bloc.dart';
import 'package:invoice_app/blocs/bloc/items_bloc.dart';
import 'package:invoice_app/services/storage.dart';

import 'Widgets/bottombar.dart';
import 'blocs/bloc/categories_bloc.dart';
import 'blocs/bloc/tax_bloc.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => BuisnessBloc(Storage()),
        ),
        BlocProvider(
          create: (context) => ClientBloc(Storage()),
        ),
        BlocProvider(
          create: (context) => InvoiceBloc(Storage()),
        ),
        BlocProvider(create: ((context) => ItemsBloc(Storage()))),
        BlocProvider(
          create: (context) => TaxBloc(Storage()),
        ),
        BlocProvider(
          create: (context) => BuisnessBloc(Storage()),
        ),
        BlocProvider(
          create: (context) => CategoriesBloc(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Invoices',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
          useMaterial3: true,
        ),
        home: const BottomNavBar(),
      ),
    );
  }
}

Color white = Colors.white;
Color primaryDark = fromHex('#2b488e');
Color primary = fromHex('#4f75b6');
Color primaryLight = fromHex("#719bd1");
Color primaryExtraLight = fromHex('#8da0cb');
Color black = Colors.black;
Color greyLight = const Color.fromARGB(255, 225, 225, 225);
Color grey = Colors.grey;

Color fromHex(String hexString) {
  final buffer = StringBuffer();
  if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
  buffer.write(hexString.replaceFirst('#', ''));
  return Color(int.parse(buffer.toString(), radix: 16));
}
