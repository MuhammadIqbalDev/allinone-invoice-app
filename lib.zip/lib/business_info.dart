// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:developer';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';

import 'package:invoice_app/Constants/colors.dart';
import 'package:invoice_app/Widgets/textFormFieldWidget.dart';
import 'package:invoice_app/blocs/bloc/buisness_bloc.dart';
import 'package:invoice_app/model/businessInfo.dart';

import 'invoice_home.dart';
import 'main.dart';

class BusinessInfo extends StatefulWidget {
  final Business_Info? EditingBusiness;
  const BusinessInfo({
    Key? key,
    this.EditingBusiness,
  }) : super(key: key);

  @override
  State<BusinessInfo> createState() => _BusinessInfoState();
}

class _BusinessInfoState extends State<BusinessInfo> {
  XFile? _pickedImage;
  final TextEditingController _textFieldNameController =
      TextEditingController();
  final TextEditingController _textFieldAddressController =
      TextEditingController();
  final TextEditingController _textFieldPhoneController =
      TextEditingController();
  final TextEditingController _textFieldEmailController =
      TextEditingController();

  String? _nameError;
  String? _addressError;
  String? _phoneError;
  String? _emailError;

  Future<void> _getImageFromGallery() async {
    final pickedImage =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      _pickedImage = pickedImage;
    });
  }

  @override
  void initState() {
    if (widget.EditingBusiness != null) {
      _textFieldNameController.text = widget.EditingBusiness!.name;
      _textFieldAddressController.text = widget.EditingBusiness!.address;
      _textFieldPhoneController.text = widget.EditingBusiness!.phone.toString();
      _textFieldEmailController.text = widget.EditingBusiness!.email;
    }
    super.initState();
  }

  @override
  void dispose() {
    _textFieldNameController.dispose();
    _textFieldAddressController.dispose();
    _textFieldEmailController.dispose();
    _textFieldPhoneController.dispose();
    super.dispose();
  }

  void _proceedToNextScreen() {
    setState(() {
      _nameError = _textFieldNameController.text.isEmpty
          ? 'Please fill in name field'
          : null;
      _addressError = _textFieldAddressController.text.isEmpty
          ? 'Please fill in address field'
          : null;
      _phoneError = _textFieldPhoneController.text.isEmpty
          ? 'Please fill in phone field'
          : null;
      _emailError = _textFieldEmailController.text.isEmpty
          ? 'Please fill in email field'
          : null;
    });

    // if (_nameError == null &&
    //     _addressError == null &&
    //     _phoneError == null &&
    //     _emailError == null) {
    //   Business_Info binfo = Business_Info(
    //     widget.EditingBusiness!=null? widget.EditingBusiness!.business_id:
    //       name: _textFieldNameController.text,
    //       address: _textFieldAddressController.text,
    //       image: null,
    //       email: _textFieldEmailController.text);
    //   context.read<BuisnessBloc>().add(AddBuisness(buisness: binfo));
    //   context.read<BuisnessBloc>().add(selectedBuisness(sb: binfo));
    // Navigator.of(context).pop();
    // Navigator.of(context).push(
    //   MaterialPageRoute(
    //     builder: (context) => NewInvoice(
    //       binfo: binfo,
    //     ),
    //   ),
    // );
    // }
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width;
    double hieght = MediaQuery.sizeOf(context).width;
    return BlocBuilder<BuisnessBloc, BuisnessState>(builder: (context, bstate) {
      return Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.close),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
          title: Text(
            'Bussiness Info',
            style: tstyle(size: 20, fw: FontWeight.w600),
          ),
          actions: [
            TextButton(
                onPressed: () {
                  // _proceedToNextScreen();
                  setState(() {
                    _nameError = _textFieldNameController.text.isEmpty
                        ? 'Please fill in name field'
                        : null;
                    _addressError = _textFieldAddressController.text.isEmpty
                        ? 'Please fill in address field'
                        : null;
                    _phoneError = _textFieldPhoneController.text.isEmpty
                        ? 'Please fill in phone field'
                        : null;
                    _emailError = _textFieldEmailController.text.isEmpty
                        ? 'Please fill in email field'
                        : null;
                  });

                  if (_nameError == null &&
                      _addressError == null &&
                      _phoneError == null &&
                      _emailError == null) {
                    Business_Info binfo = Business_Info(
                        widget.EditingBusiness != null
                            ? widget.EditingBusiness!.business_id
                            : bstate.businessList.length + 1,
                        _textFieldNameController.text,
                        _textFieldAddressController.text,
                        int.tryParse(_textFieldPhoneController.text),
                        null,
                        _textFieldEmailController.text);

                    if (widget.EditingBusiness != null) {
                      context
                          .read<BuisnessBloc>()
                          .add(EditBusiness(editBusiness: binfo));
                    } else {
                      context
                          .read<BuisnessBloc>()
                          .add(AddBuisness(buisness: binfo));
                      context
                          .read<BuisnessBloc>()
                          .add(selectedBuisness(sb: binfo));
                    }
                    // Navigator.of(context).pop();
                    // Navigator.of(context).push(
                    //   MaterialPageRoute(
                    //     builder: (context) => NewInvoice(
                    //       binfo: binfo,
                    //     ),
                    //   ),
                    // );
                  }
                  log('${bstate.businessList}');
                  Navigator.of(context).pop();
                },
                child: Text(
                  "SAVE",
                  style: tstyle(
                    size: 16,
                    fw: FontWeight.w400,
                    color: grey,
                  ),
                ))
          ],
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SafeArea(
                  child: InkWell(
                    onTap: _getImageFromGallery,
                    child: DottedBorder(
                      color: grey.withOpacity(0.4),
                      borderType: BorderType.RRect,
                      radius: const Radius.circular(20),
                      dashPattern: const [10, 10],
                      strokeWidth: 1,
                      child: SizedBox(
                        width: width * 0.3,
                        height: width * 0.3,
                        child: Center(
                          child: Text(
                            'LOGO',
                            style: tstyle(
                              size: 16,
                              fw: FontWeight.w400,
                              color: grey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                      width: 300,
                      child: CustomTextFormField(
                        controller: _textFieldNameController,
                        labelText: "Name",
                        errorText: _nameError,
                        cursorColor: AppColors.PrimaryColor,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    width: 300,
                    child: CustomTextFormField(
                      controller: _textFieldAddressController,
                      labelText: "Address",
                      cursorColor: AppColors.PrimaryColor,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                      width: 300,
                      child: CustomTextFormField(
                        cursorColor: AppColors.PrimaryColor,
                        controller: _textFieldPhoneController,
                        labelText: "Phone",
                        keyboardType: TextInputType.number,
                      )),
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                      width: 300,
                      child: CustomTextFormField(
                        controller: _textFieldEmailController,
                        labelText: "Email",
                        cursorColor: AppColors.PrimaryColor,
                      )),
                ),
                // const SizedBox(
                //   height: 20,
                // ),
                // Padding(
                //   padding: const EdgeInsets.all(8.0),
                //   child: Container(
                //     alignment: Alignment.bottomRight,
                //     child: ElevatedButton(
                //       style: ElevatedButton.styleFrom(
                //         padding: const EdgeInsets.symmetric(
                //             horizontal: 20, vertical: 10),
                //         backgroundColor: Colors.white,
                //         shape: RoundedRectangleBorder(
                //           borderRadius: BorderRadius.circular(10),
                //         ),
                //       ),
                //       onPressed: () async{
                //         Business_Info buisness = Business_Info(
                //             name: _textFieldNameController.text,
                //             address: _textFieldAddressController.text,
                //             email: _textFieldEmailController.text);
                //         context.read<BuisnessBloc>().add(AddBuisness(buisness: buisness));
                //          await Storage().getBusinessDetails();
                //         // context.read<BuisnessBloc>().add(AllBuisness(buisness:));

                //        _proceedToNextScreen();
                //       },
                //       child: const Text(
                //         'Next',
                //         style: TextStyle(fontSize: 16, color: Colors.grey),
                //       ),
                //     ),
                //   ),
                // )
              ],
            ),
          ),
        ),
      );
    });
  }
}
