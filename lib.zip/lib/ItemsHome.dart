// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:invoice_app/Dialogs/add_item.dart';
import 'package:invoice_app/model/itemModel.dart';

import 'Widgets/myDrawer.dart';
import 'blocs/bloc/items_bloc.dart';
import 'invoice_home.dart';
import 'main.dart';

class ItemsHome extends StatefulWidget {
  final bool isModal;
  const ItemsHome({
    Key? key,
    required this.isModal,
  }) : super(key: key);

  @override
  State<ItemsHome> createState() => _ItemsHomeState();
}

class _ItemsHomeState extends State<ItemsHome> {
  @override
  Widget build(BuildContext context) {
    double hieght = MediaQuery.sizeOf(context).height;
    double width = MediaQuery.sizeOf(context).width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Items',
          style: tstyle(size: 25, fw: FontWeight.bold),
        ),
      ),
      drawer: const MyDrawer(),
      body: BlocBuilder<ItemsBloc, ItemsState>(builder: (context, state) {
        return Container(
            child: state.allItem.isNotEmpty
                ? ListView.builder(
                    itemCount: state.allItem.length,
                    itemBuilder: (context, index) {
                      AddItem item = state.allItem[index];
                      return InkWell(
                        onTap: () async {
                          if (widget.isModal) {
                            Navigator.of(context).pop();
                            // Navigator.of(context).pop();
                            await showModalBottomSheet(
                                context: context,
                                builder: ((context) => NewItem(
                                      isModal: widget.isModal,
                                      item: item,
                                    )));
                          } else {
                            Navigator.of(context)
                                .push(MaterialPageRoute(builder: (context) {
                              return NewItem(item: item, isModal: widget.isModal, EditingItem: item);
                            }));
                          }
                          //  context
                          //     .read<ItemsBloc>()
                          //     .add(SelectedItems(selectedItem: item));
                        },
                        child: Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  // Container(
                                  //   margin: const EdgeInsets.all(5),
                                  //   width: width * 0.2,
                                  //   height: width * 0.2,
                                  //   decoration: BoxDecoration(color: greyLight.withOpacity(0.4),
                                  //   borderRadius: BorderRadius.circular(10),
                                  //   ),
                                  //   child: Center(child: Text(client.clientName[0].toUpperCase(),style: tstyle(color: black,size: 40,fw: FontWeight.bold),)),
                                  // ),
                                  // const SizedBox(width: 5,),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                        "${item.itemName[0].toUpperCase()}${item.itemName.substring(1)}",
                                        style: tstyle(
                                            fw: FontWeight.w500, size: 20),
                                      ),
                                      Text(
                                        item.description,
                                        textAlign: TextAlign.end,
                                        style: tstyle(
                                            fw: FontWeight.w300, size: 17),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            "\$${item.unitPrice}",
                                            style: tstyle(
                                                fw: FontWeight.w500, size: 20),
                                          ),
                                          Text(
                                            item.unit,
                                            style: tstyle(
                                                fw: FontWeight.w300, size: 17),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(
                                        width: 30,
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                            border: Border(
                                                left: BorderSide(
                                                    color: grey
                                                        .withOpacity(0.8)))),
                                        child: IconButton(
                                          icon: const Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                          onPressed: () {
                                            context
                                                .read<ItemsBloc>()
                                                .add(DeleteFromAllItems(item));
                                          },
                                        ),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                              Divider(
                                color: greyLight,
                              )
                            ],
                          ),
                        ),
                      );
                    })
                : Container(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Image(
                            image:
                                const AssetImage('assets/images/noitems.png'),
                            height: hieght * 0.4,
                          ),
                          if (!widget.isModal)
                            Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(
                                    "No Items!",
                                    style:
                                        tstyle(size: 25, fw: FontWeight.w500),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Text(
                                    "Please tap on the plus (+) button bellow to create an item.",
                                    style: tstyle(
                                      size: 20,
                                      color: grey.withOpacity(0.8),
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                              ],
                            )
                        ],
                      ),
                    ),
                  ));
      }),
      floatingActionButton: SizedBox(
        height: 50,
        width: 50,
        child: FloatingActionButton(
          backgroundColor: primary,
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(50), // Customize the border radius here
          ),
          onPressed: () {
            if (widget.isModal) {
              Navigator.of(context).pop();
            }
            Navigator.of(context).push(MaterialPageRoute(builder: (context) {
              return NewItem(
                isModal: widget.isModal,
                item: null,
              );
            }));
          },

          child: Icon(
            Icons.add,
            color: white,
            size: 30,
          ), // Customize the button color here
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
