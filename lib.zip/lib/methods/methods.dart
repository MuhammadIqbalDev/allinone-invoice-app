
double calculateSubtotal(double unitPrice, double quantity) {
  return unitPrice * quantity;
}