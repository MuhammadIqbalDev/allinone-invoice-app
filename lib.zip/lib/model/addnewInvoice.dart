// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:invoice_app/model/itemModel.dart';

import 'businessInfo.dart';
import 'clientModel.dart';

class InvoiceModel {
  final int invoice_id;
  final Business_Info business;
  final ClientModel Client;
  final List<AddItem> items;
  final double subtotal;
  final double total;
  final double tax;
  final double discount;
  final DateTime date;
  InvoiceModel({
    required this.invoice_id,
    required this.business,
    required this.Client,
    required this.items,
    required this.subtotal,
    required this.total,
    required this.tax,
    required this.discount,
    required this.date,
  });

  InvoiceModel copyWith({
    int? invoice_id,
    Business_Info? business,
    ClientModel? Client,
    List<AddItem>? items,
    double? subtotal,
    double? total,
    double? tax,
    double? discount,
    DateTime? date,
  }) {
    return InvoiceModel(
      invoice_id: invoice_id ?? this.invoice_id,
      business: business ?? this.business,
      Client: Client ?? this.Client,
      items: items ?? this.items,
      subtotal: subtotal ?? this.subtotal,
      total: total ?? this.total,
      tax: tax ?? this.tax,
      discount: discount ?? this.discount,
      date: date ?? this.date,
    );
  }

  Map<String, dynamic> toMap({InvoiceModel? i}) {
    

    return i != null
        ? <String, dynamic>{
            'invoice_id': invoice_id,
            'business': Business_Info.toMap(b: i.business),
            'Client': ClientModel.toMap(c: i.Client),
            'items': AddItem.convertListToMap(i.items),
            'subtotal': subtotal,
            'total': total,
            'tax': tax,
            'discount': discount,
            'date': date.millisecondsSinceEpoch,
          }
        : {'invoices:': []};
  }

  factory InvoiceModel.fromMap(Map<String, dynamic> map) {
    return InvoiceModel(
      invoice_id: map['invoice_id'] as int,
      business: Business_Info.fromMap(map['business'] as Map<String, dynamic>),
      Client: ClientModel.fromMap(map['Client'] as Map<String, dynamic>),
      items: List<AddItem>.from(
        (map['items'] as List<int>).map<AddItem>(
          (x) => AddItem.fromMap(x as Map<String, dynamic>),
        ),
      ),
      subtotal: map['subtotal'] as double,
      total: map['total'] as double,
      tax: map['tax'] as double,
      discount: map['discount'] as double,
      date: DateTime.fromMillisecondsSinceEpoch(map['date'] as int),
    );
  }

  String toJson() => json.encode(toMap());

  factory InvoiceModel.fromJson(String source) =>
      InvoiceModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  String toString() {
    return 'InvoiceModel(invoice_id: $invoice_id, business: $business, Client: $Client, items: $items, subtotal: $subtotal, total: $total, tax: $tax, discount: $discount, date: $date)';
  }

  @override
  bool operator ==(covariant InvoiceModel other) {
    if (identical(this, other)) return true;

    return other.invoice_id == invoice_id &&
        other.business == business &&
        other.Client == Client &&
        listEquals(other.items, items) &&
        other.subtotal == subtotal &&
        other.total == total &&
        other.tax == tax &&
        other.discount == discount &&
        other.date == date;
  }

  @override
  int get hashCode {
    return invoice_id.hashCode ^
        business.hashCode ^
        Client.hashCode ^
        items.hashCode ^
        subtotal.hashCode ^
        total.hashCode ^
        tax.hashCode ^
        discount.hashCode ^
        date.hashCode;
  }
}
