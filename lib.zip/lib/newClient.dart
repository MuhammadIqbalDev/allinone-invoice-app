import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:invoice_app/blocs/bloc/client_bloc.dart';
import 'package:invoice_app/model/clientModel.dart';

import 'Widgets/textFormFieldWidget.dart';
import 'invoice_home.dart';
import 'main.dart';

class newClient extends StatefulWidget {
  final ClientModel? EditingClient;
  const newClient({super.key, this.EditingClient});

  @override
  State<newClient> createState() => _newClientState();
}

class _newClientState extends State<newClient> {
  XFile? _pickedImage;
  final TextEditingController _textFieldNameController =
      TextEditingController();
  final TextEditingController _textFieldAddressController =
      TextEditingController();
  final TextEditingController _textFieldPhoneController =
      TextEditingController();
  final TextEditingController _textFieldEmailController =
      TextEditingController();

  @override
  void initState() {
    if (widget.EditingClient != null) {
      _textFieldNameController.text = widget.EditingClient!.clientName;
      _textFieldAddressController.text = widget.EditingClient!.clientAddress;
      _textFieldPhoneController.text = widget.EditingClient!.clientPhone;
      _textFieldEmailController.text = widget.EditingClient!.clientEmail;
    }
    super.initState();
  }

  String? _nameError;
  String? _addressError;
  String? _phoneError;
  String? _emailError;

  Future<void> _getImageFromGallery() async {
    final pickedImage =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      _pickedImage = pickedImage;
    });
  }

  @override
  void dispose() {
    _textFieldNameController.dispose();
    _textFieldAddressController.dispose();
    _textFieldEmailController.dispose();
    _textFieldPhoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width;
    double hieght = MediaQuery.sizeOf(context).width;
    return BlocBuilder<ClientBloc, ClientState>(
      builder: (context, cstate) {
        return Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.close),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            title: Text(
              'Add new client',
              style: tstyle(size: 20, fw: FontWeight.w600),
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    setState(() {
                      _nameError = _textFieldNameController.text.isEmpty
                          ? 'Please fill in name field'
                          : null;
                      _addressError = _textFieldAddressController.text.isEmpty
                          ? 'Please fill in address field'
                          : null;
                      _phoneError = _textFieldPhoneController.text.isEmpty
                          ? 'Please fill in phone field'
                          : null;
                      _emailError = _textFieldEmailController.text.isEmpty
                          ? 'Please fill in email field'
                          : null;
                    });

                    if (_nameError == null &&
                        _addressError == null &&
                        _phoneError == null &&
                        _emailError == null) {
                      ClientModel createdClient = ClientModel(
                          widget.EditingClient!=null ? widget.EditingClient!.client_id : cstate.clientList.length+1,
                          _textFieldNameController.text,
                          _textFieldAddressController.text,
                          _textFieldPhoneController.text,
                          _textFieldEmailController.text);
                      if (widget.EditingClient != null) {
                         context
                            .read<ClientBloc>()
                            .add(EditClient(editclient: createdClient));
                      } else {
                        context
                            .read<ClientBloc>()
                            .add(AddClient(client: createdClient));
                        context
                            .read<ClientBloc>()
                            .add(selectedClient(Sc: createdClient));
                      }
                   
                    }
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    "SAVE",
                    style: tstyle(
                      size: 16,
                      fw: FontWeight.w400,
                      color: grey,
                    ),
                  ))
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(20.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SafeArea(
                    child: InkWell(
                      onTap: _getImageFromGallery,
                      child: DottedBorder(
                        color: grey.withOpacity(0.4),
                        borderType: BorderType.RRect,
                        radius: const Radius.circular(20),
                        dashPattern: const [10, 10],
                        strokeWidth: 1,
                        child: Container(
                          width: width * 0.3,
                          height: width * 0.3,
                          decoration: const BoxDecoration(
                              image: DecorationImage(
                                  image:
                                      AssetImage('assets/images/profile.png'))),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CustomTextFormField(
                      controller: _textFieldNameController,
                      labelText: "Name",
                      errorText: _nameError,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CustomTextFormField(
                      controller: _textFieldAddressController,
                      labelText: "Address",
                      errorText: _addressError,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CustomTextFormField(
                      controller: _textFieldPhoneController,
                      labelText: "Phone",
                      keyboardType: TextInputType.number,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CustomTextFormField(
                      controller: _textFieldEmailController,
                      labelText: "Email",
                      errorText: _emailError,
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
