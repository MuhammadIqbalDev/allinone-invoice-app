// import 'dart:html';

import 'package:bloc/bloc.dart';
import 'package:invoice_app/services/storage.dart';

import '../../model/itemModel.dart';

part 'items_event.dart';
part 'items_state.dart';

class ItemsBloc extends Bloc<ItemsEvent, ItemsState> {
  ItemsBloc(Storage st) : super(ItemsState(allItem: [], selectedItems: [])) {
    on<getAllItems>((event, emit) {
      final List<AddItem> allitem = event.allItems;
      emit(ItemsState(allItem: allitem, selectedItems: state.selectedItems));
    });
    on<AddNew>((event, emit) async {
      List<AddItem> allitem = [...state.allItem];
      allitem.add(event.item);

      emit(ItemsState(allItem: allitem, selectedItems: state.selectedItems));
      await st.saveItemDetails(allitem);
    });
    on<SelectedItems>((event, emit) {
      // final AddItem selecteditem = event.selectedItem;
      List<AddItem> allitem = state.selectedItems;
      // allitem.add(selecteditem);

      emit(ItemsState(
        allItem: state.allItem,
        selectedItems: state.allItem
      ));
    });
    on<defaultSelected>(
      (event, emit) {
        emit(ItemsState(allItem: state.allItem, selectedItems: []));
      },
    );
    on<DeleteFromAllItems>((event, emit) async {
      List<AddItem> itemslist = [...state.allItem];
      itemslist.removeAt(event.item.itemId-1);
      emit(ItemsState(
        allItem: itemslist,
        selectedItems: state.selectedItems
          ..removeWhere((element) => (element.itemId == event.item.itemId))
         
      ));
       await st.saveItemDetails(itemslist);
    });
    on<DeleteSelectedItems>((event, emit) {
      emit(ItemsState(
          selectedItems: state.selectedItems, allItem: state.allItem));
    });
    on<EditItems>((event, emit) {
      emit(ItemsState(
          selectedItems: state.selectedItems,
          allItem: state.allItem
            ..removeWhere(
                (element) => (element.itemId == event.editItem.itemId))
            ..add(event.editItem),
          item: state.item));
    });
  }
}
