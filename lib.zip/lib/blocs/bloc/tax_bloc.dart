import 'package:bloc/bloc.dart';
import 'package:invoice_app/services/storage.dart';
// import 'package:meta/meta.dart';

import '../../model/taxModal.dart';

part 'tax_event.dart';
part 'tax_state.dart';

class TaxBloc extends Bloc<TaxEvent, TaxState> {
  TaxBloc(Storage st) : super(TaxState(allTax: [], selectedTax: null)) {
    on<getAllTax>((event, emit) {
      final List<AddTax> allTax =
          state.allTax.isNotEmpty ? event.allTax : state.allTax;

      emit(TaxState(allTax: allTax, selectedTax: state.selectedTax));
    });
    on<AddNewTax>((event, emit) {
      List<AddTax> allTax = state.allTax;
      allTax.add(event.tax);
      emit(TaxState(allTax: allTax, selectedTax: state.selectedTax));
      st.saveTaxDetails(allTax);
    });
    on<SelectedTax>((event, emit) {
      AddTax selectedTax = event.selectedTax;
      emit(TaxState(allTax: state.allTax, selectedTax: selectedTax));
    });
    on<DeleteTax>((event, emit) {
      emit(TaxState(
          allTax: state.allTax
            ..removeWhere((element) => element.tax_id == event.tax.tax_id),
          selectedTax: state.selectedTax));
    });
    on<EditTax>((event, emit) {
      emit(TaxState(
          allTax: state.allTax
            ..removeWhere((element) => (element.tax_id == event.editTax.tax_id))
            ..add(event.editTax),
          selectedTax: state.selectedTax));
    });
  }
}
