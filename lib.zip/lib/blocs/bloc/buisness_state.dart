// ignore_for_file: public_member_api_docs, sort_constructors_first
part of 'buisness_bloc.dart';

class BuisnessState {
  final List<Business_Info> businessList;
  final Business_Info? sb;
  BuisnessState({
    required this.businessList,
    required this.sb,
  });
}
