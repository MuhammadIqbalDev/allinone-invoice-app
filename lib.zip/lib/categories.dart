import 'package:flutter/material.dart';

import 'Widgets/myDrawer.dart';
import 'invoice_home.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(
        centerTitle: true,
        title: Text(
          'Categories',
          style: tstyle(size: 25, fw: FontWeight.bold),
        ),
      ),
      drawer: const MyDrawer(),
      body: const Center(child:Text('Coming Soon....',style: TextStyle(fontSize: 25,),)),
    );
  }
}