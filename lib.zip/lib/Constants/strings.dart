import '../Dialogs/add_item.dart';
import '../model/addnewInvoice.dart';
import '../model/clientModel.dart';
import '../model/itemModel.dart';

class AppStrings {
  static String App_title = "Invoices";
}

List<ClientModel> allClients = [];
List<AddItem> allItems = [];
List<InvoiceModel> allInvoices = [];
