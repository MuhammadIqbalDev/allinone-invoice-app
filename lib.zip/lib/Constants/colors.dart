import 'package:flutter/material.dart';

class AppColors {
  static Color PrimaryColor = Color.fromRGBO(174, 213, 129, 1);

}
