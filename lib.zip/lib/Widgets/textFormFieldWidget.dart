// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:invoice_app/main.dart';


class CustomTextFormField extends StatelessWidget {
  final TextEditingController controller;
  final String? labelText;
  final Color cursorColor;
  final String? errorText;
  final Color? CursorStyle;
  final keyboardType;
  final onSaved;
  // final bool editable;

  const CustomTextFormField({
    super.key,
    // this.editable = false,
    required this.controller,
    this.labelText,
    this.cursorColor = Colors.grey,
    this.errorText,
    this.CursorStyle,
    this.keyboardType,
    this.onSaved,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: TextFormField(
        
          onSaved: onSaved,
          keyboardType: keyboardType,
          cursorColor: cursorColor,
          controller: controller,
          // enabled: editable,
          decoration: InputDecoration(
            
            
            labelText: labelText,
            labelStyle: TextStyle(color: black.withOpacity(0.5)),
            enabledBorder:UnderlineInputBorder(
                borderSide: BorderSide(color: grey.withOpacity(0.2))), 
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: grey.withOpacity(0.2))),
            errorStyle: const TextStyle(color: Colors.red),
            border: UnderlineInputBorder(
              borderSide: BorderSide(color: grey.withOpacity(0.2))
            )
          )),
    );
  }
}
